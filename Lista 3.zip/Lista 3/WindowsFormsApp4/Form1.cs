﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtCalcular_Click(object sender, EventArgs e)
        {
            if ((TbBase.Text != "") && (TbAltura.Text != ""))
            {
                float resultado = float.Parse(TbBase.Text) * float.Parse(TbAltura.Text) / 2;
                TbArea.Text = resultado.ToString();
                LbMensagem.Text = "Calculo efetuado!!";
            }
            else
            {
                LbMensagem.Text = "Digite os respectivos valores para efetuar o calculo...";
            }

        }

        private void BtLimpar_Click(object sender, EventArgs e)
        {
            TbAltura.Text = null;
            TbBase.Text = null;
            TbArea.Text = null;
            LbMensagem.Text = null;
        }
    }
}
