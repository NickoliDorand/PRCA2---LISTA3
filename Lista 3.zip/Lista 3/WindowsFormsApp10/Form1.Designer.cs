﻿namespace WindowsFormsApp9
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_VA = new System.Windows.Forms.Label();
            this.LbMensagem = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_VB = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.text_Resultado = new System.Windows.Forms.TextBox();
            this.text_VA = new System.Windows.Forms.TextBox();
            this.BtLimpar = new System.Windows.Forms.Button();
            this.BtComparar = new System.Windows.Forms.Button();
            this.text_VB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_VA
            // 
            this.lbl_VA.AutoSize = true;
            this.lbl_VA.Location = new System.Drawing.Point(42, 55);
            this.lbl_VA.Name = "lbl_VA";
            this.lbl_VA.Size = new System.Drawing.Size(110, 13);
            this.lbl_VA.TabIndex = 32;
            this.lbl_VA.Text = "Digite o valor da base";
            // 
            // LbMensagem
            // 
            this.LbMensagem.AutoSize = true;
            this.LbMensagem.Location = new System.Drawing.Point(42, 329);
            this.LbMensagem.Name = "LbMensagem";
            this.LbMensagem.Size = new System.Drawing.Size(0, 13);
            this.LbMensagem.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 256);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 13);
            this.label3.TabIndex = 30;
            this.label3.Text = "Aqui está o resultado";
            // 
            // lbl_VB
            // 
            this.lbl_VB.AutoSize = true;
            this.lbl_VB.Location = new System.Drawing.Point(42, 116);
            this.lbl_VB.Name = "lbl_VB";
            this.lbl_VB.Size = new System.Drawing.Size(113, 13);
            this.lbl_VB.TabIndex = 29;
            this.lbl_VB.Text = "Digite o valor da altura";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(356, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Obtenha a area de um retangulo e a sua definição atraves desse software";
            // 
            // text_Resultado
            // 
            this.text_Resultado.Location = new System.Drawing.Point(45, 289);
            this.text_Resultado.Name = "text_Resultado";
            this.text_Resultado.Size = new System.Drawing.Size(274, 20);
            this.text_Resultado.TabIndex = 27;
            // 
            // text_VA
            // 
            this.text_VA.Location = new System.Drawing.Point(45, 81);
            this.text_VA.Name = "text_VA";
            this.text_VA.Size = new System.Drawing.Size(100, 20);
            this.text_VA.TabIndex = 26;
            // 
            // BtLimpar
            // 
            this.BtLimpar.Location = new System.Drawing.Point(132, 198);
            this.BtLimpar.Name = "BtLimpar";
            this.BtLimpar.Size = new System.Drawing.Size(66, 38);
            this.BtLimpar.TabIndex = 25;
            this.BtLimpar.Text = "Limpar";
            this.BtLimpar.UseVisualStyleBackColor = true;
            this.BtLimpar.Click += new System.EventHandler(this.BtLimpar_Click);
            // 
            // BtComparar
            // 
            this.BtComparar.Location = new System.Drawing.Point(45, 179);
            this.BtComparar.Name = "BtComparar";
            this.BtComparar.Size = new System.Drawing.Size(81, 57);
            this.BtComparar.TabIndex = 24;
            this.BtComparar.Text = "Calcular";
            this.BtComparar.UseVisualStyleBackColor = true;
            this.BtComparar.Click += new System.EventHandler(this.BtComparar_Click);
            // 
            // text_VB
            // 
            this.text_VB.Location = new System.Drawing.Point(45, 142);
            this.text_VB.Name = "text_VB";
            this.text_VB.Size = new System.Drawing.Size(100, 20);
            this.text_VB.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 376);
            this.Controls.Add(this.lbl_VA);
            this.Controls.Add(this.LbMensagem);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_VB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.text_Resultado);
            this.Controls.Add(this.text_VA);
            this.Controls.Add(this.BtLimpar);
            this.Controls.Add(this.BtComparar);
            this.Controls.Add(this.text_VB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_VA;
        private System.Windows.Forms.Label LbMensagem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_VB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_Resultado;
        private System.Windows.Forms.TextBox text_VA;
        private System.Windows.Forms.Button BtLimpar;
        private System.Windows.Forms.Button BtComparar;
        private System.Windows.Forms.TextBox text_VB;
    }
}

