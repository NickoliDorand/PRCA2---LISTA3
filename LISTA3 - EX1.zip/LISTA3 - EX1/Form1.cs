﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LISTA3___EX1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Retangulo area;
            area = new Retangulo();
            area.setA(int.Parse(txtAltura.Text));
            area.setB(int.Parse(txtBase.Text));
            area.calcularArea();
            lblResultado.Text = area.getArea().ToString()+"m²";
        }
    }
}
